<?php

namespace App\Service;

use Exception;
use Illuminate\Support\Facades\Log;

class SetupDefaultService
{
    public function addDomainToDns($fullDomain)
    {
        try {
            $apiToken = getenv('CLOUD_FLARE_API_TOKEN');
            $ip = getenv('SERVER_IP_ADDRESS');
            [$sub, $domain] = $this->extractSubdomainAndDomain($fullDomain, 'microgem.io.vn');

            $zoneId = $this->getZoneIdByDomain($apiToken, $domain);
            if (!$zoneId) {
                return [
                    'status' => false,
                    'message' => "Không tìm thấy Zone ID cho {$domain}"
                ];
            }

            $response = $this->createSubdomainOnCloudflare($apiToken, $zoneId, $sub, $domain, $ip);
            $responseDecode = json_decode($response, true);

            return [
                'status' => true,
                'message' => 'Tạo DNS subdomain thành công',
                'data' => $responseDecode
            ];
        } catch (Exception $e) {
            Log::error('Lỗi addDomainToDns: ' . $e->getMessage());

            return [
                'status' => false,
                'message' => 'Lỗi: ' . $e->getMessage()
            ];
        }
    }

    public function extractSubdomainAndDomain($fullDomain, $domainRoot = 'microgem.io.vn')
    {
        if (!str_ends_with($fullDomain, $domainRoot)) {
            throw new Exception("Tên miền không khớp với domain chính ($domainRoot)");
        }

        $subdomain = str_replace(".$domainRoot", '', $fullDomain);
        return [$subdomain, $domainRoot];
    }

    public function getZoneIdByDomain($apiToken, $domain)
    {
        $url = "https://api.cloudflare.com/client/v4/zones?name={$domain}";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer {$apiToken}",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data['success'] === true && count($data['result']) > 0
            ? $data['result'][0]['id']
            : null;
    }

    public function createSubdomainOnCloudflare($apiToken, $zoneId, $subdomain, $domain, $ipAddress)
    {
        $url = "https://api.cloudflare.com/client/v4/zones/{$zoneId}/dns_records";

        $postData = [
            "type" => "A",
            "name" => "{$subdomain}.{$domain}",
            "content" => $ipAddress,
            "ttl" => 1,
            "proxied" => false
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer {$apiToken}",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

        $response = curl_exec($ch);
        curl_close($ch);

        return $response;
    }

    public function addDomainToVirtualHost($domain)
    {
        $projectPath = '/var/www/html/sheetany_blog/dist';
        return $this->addApacheVirtualHost($domain, $projectPath);
    }

    public function addApacheVirtualHost($domain, $projectPath)
    {
        try {
            $confPath = "/etc/apache2/sites-available/{$domain}.conf";

            $vhostConfig = <<<EOL
                <VirtualHost *:80>
                    ServerName {$domain}
                    DocumentRoot {$projectPath}

                    <Directory {$projectPath}>
                        Options Indexes FollowSymLinks
                        AllowOverride All
                        Require all granted
                    </Directory>

                    ErrorLog \${APACHE_LOG_DIR}/{$domain}_error.log
                    CustomLog \${APACHE_LOG_DIR}/{$domain}_access.log combined
                </VirtualHost>
                EOL;

            file_put_contents($confPath, $vhostConfig);

            exec("sudo a2ensite {$domain}.conf", $output1, $code1);
            exec("sudo systemctl reload apache2", $output2, $code2);

            if ($code1 === 0 && $code2 === 0) {
                return [
                    'status' => true,
                    'message' => "Đã tạo và kích hoạt VirtualHost cho {$domain}",
                    'output' => [
                        'a2ensite' => $output1,
                        'reload' => $output2
                    ]
                ];
            } else {
                return [
                    'status' => false,
                    'message' => 'Có lỗi khi kích hoạt VirtualHost.',
                    'output' => [
                        'a2ensite' => $output1,
                        'reload' => $output2
                    ]
                ];
            }
        } catch (Exception $e) {
            Log::error('Lỗi khi tạo VirtualHost: ' . $e->getMessage());

            return [
                'status' => false,
                'message' => 'Lỗi khi tạo VirtualHost: ' . $e->getMessage()
            ];
        }
    }
}
