<?php

namespace App\Http\Controllers;

use App\Models\Site;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Exception;

class ApiTestController extends Controller
{
    public function index(Request $request)
    {
        try {
            $apiToken = getenv('CLOUD_FLARE_API_TOKEN');
            $ip = getenv('SERVER_IP_ADDRESS');
            $fullDomain = $request->full_domain;

            [$sub, $domain] = $this->extractSubdomainAndDomain($fullDomain, 'microgem.io.vn');
            $zoneId = $this->getZoneIdByDomain($apiToken, $domain);

            if (!$zoneId) {
                return response()->json([
                    'status' => false,
                    'message' => "Không tìm thấy Zone ID cho {$domain}"
                ]);
            }

            $response = $this->createSubdomainOnCloudflare($apiToken, $zoneId, $sub, $domain, $ip);
            $projectPath = '/var/www/html/sheetany_blog/dist';
            $vhostResult = $this->addApacheVirtualHost($fullDomain, $projectPath);

            return response()->json([
                'status' => true,
                'message' => 'Tạo subdomain và VirtualHost thành công.',
                'data' => [
                    'cloudflare_response' => json_decode($response, true),
                    'vhost_result' => $vhostResult
                ]
            ]);
        } catch (Exception $e) {
            Log::error('Lỗi khi tạo subdomain: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Lỗi: ' . $e->getMessage()
            ]);
        }
    }

    public function extractSubdomainAndDomain($fullDomain, $domainRoot = 'microgem.io.vn') {
        if (!str_ends_with($fullDomain, $domainRoot)) {
            throw new Exception("Tên miền không khớp với domain chính ({$domainRoot})");
        }

        $subdomain = str_replace(".$domainRoot", '', $fullDomain);
        return [$subdomain, $domainRoot];
    }

    public function getZoneIdByDomain($apiToken, $domain) {
        $url = "https://api.cloudflare.com/client/v4/zones?name={$domain}";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer {$apiToken}",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data['success'] === true && count($data['result']) > 0 ? $data['result'][0]['id'] : null;
    }

    public function createSubdomainOnCloudflare($apiToken, $zoneId, $subdomain, $domain, $ipAddress) {
        $url = "https://api.cloudflare.com/client/v4/zones/{$zoneId}/dns_records";

        $postData = [
            "type"    => "A",
            "name"    => "{$subdomain}.{$domain}",
            "content" => $ipAddress,
            "ttl"     => 1,
            "proxied" => false
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer {$apiToken}",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        $response = curl_exec($ch);
        curl_close($ch);

        return $response;
    }

    public function addApacheVirtualHost($domain, $projectPath)
    {
        $confPath = "/etc/apache2/sites-available/{$domain}.conf";

        $vhostConfig = <<<EOL
            <VirtualHost *:80>
                ServerName {$domain}
                DocumentRoot {$projectPath}

                <Directory {$projectPath}>
                    Options Indexes FollowSymLinks
                    AllowOverride All
                    Require all granted
                </Directory>

                ErrorLog \${APACHE_LOG_DIR}/{$domain}_error.log
                CustomLog \${APACHE_LOG_DIR}/{$domain}_access.log combined
            </VirtualHost>
            EOL;

        $command = "echo " . escapeshellarg($vhostConfig) . " | sudo tee {$confPath} > /dev/null";
        exec($command, $output1, $code1);

        if ($code1 !== 0) {
            return [
                'status' => false,
                'message' => "Không thể tạo file cấu hình (có thể do thiếu quyền sudo)."
            ];
        }

        exec("sudo a2ensite {$domain}.conf", $out1, $c1);
        exec("sudo a2enmod ssl", $out2);
        exec("sudo systemctl reload apache2", $out3, $c2);

        if ($c1 === 0 && $c2 === 0) {
            return [
                'status' => true,
                'message' => "Đã tạo và kích hoạt VirtualHost cho {$domain}.",
                'output' => [$out1, $out3]
            ];
        }

        return [
            'status' => false,
            'message' => 'Có lỗi xảy ra khi kích hoạt VirtualHost.',
            'output' => [$out1 ?? '', $out3 ?? '']
        ];
    }

    public function enableSSL($domain)
    {
        try {
            $cmd = "sudo certbot --apache --non-interactive --agree-tos -m your-email@example.com -d {$domain}";
            exec($cmd, $output, $return_var);

            return [
                'status' => $return_var === 0,
                'message' => $return_var === 0
                    ? "SSL đã được cài đặt thành công cho {$domain}"
                    : "Cài đặt SSL thất bại. Vui lòng kiểm tra log Certbot.",
                'output' => $output
            ];
        } catch (Exception $e) {
            return [
                'status' => false,
                'message' => 'Lỗi khi cài SSL: ' . $e->getMessage()
            ];
        }
    }
}
