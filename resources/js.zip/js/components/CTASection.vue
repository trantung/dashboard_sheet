<template>
    <section class="bg-dark text-white py-5">
        <div class="container text-center py-4">
            <h3 class="fw-bold mb-3">Ready to Kickstart Your Website?</h3>
            <p class="text-light mb-4">Create, customize and publish your site today.</p>
            <button class="btn btn-success btn-lg">Try free now →</button>
        </div>
    </section>
</template>

<script setup>
// Call to action
</script>


