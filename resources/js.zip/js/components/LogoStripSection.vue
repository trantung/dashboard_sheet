<template>
    <section class="bg-white py-4 py-md-5 border-top border-bottom">
        <div class="container">
            <div class="text-center mb-3 mb-md-4">
                <small class="text-muted">Trusted by makers from</small>
            </div>
            <div class="d-flex flex-wrap justify-content-center align-items-center gap-3 gap-md-4">
                <div class="badge bg-light text-dark fw-medium px-3 py-2">
                    <i class="bi bi-lightning-charge text-warning me-1"></i>
                    Product Hunt
                </div>
                <div class="badge bg-light text-dark fw-medium px-3 py-2">
                    <i class="bi bi-people me-1"></i>
                    Indie Hackers
                </div>
                <div class="badge bg-light text-dark fw-medium px-3 py-2">
                    <i class="bi bi-github me-1"></i>
                    GitHub Makers
                </div>
                <div class="badge bg-light text-dark fw-medium px-3 py-2">
                    <i class="bi bi-twitter-x me-1"></i>
                    Twitter Builders
                </div>
                <div class="badge bg-light text-dark fw-medium px-3 py-2">
                    <i class="bi bi-google me-1"></i>
                    Google Workspace
                </div>
            </div>
        </div>
    </section>
</template>

<script setup>
// Simple logo/text strip
</script>


