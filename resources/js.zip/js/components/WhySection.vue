<template>
    <section class="py-5 bg-white">
        <div class="container py-4">
            <div class="text-center mb-4 mb-md-5">
                <h2 class="fw-bold mb-3">Why build websites with SheetExpress?</h2>
                <p class="text-muted mx-auto" style="max-width: 680px;">
                    Manage content in Google Sheets, publish beautiful sites in minutes. No code, no headache.
                </p>
            </div>

            <div class="row g-3 g-md-4">
                <div class="col-12 col-md-4">
                    <div class="h-100 p-3 p-md-4 border rounded bg-light">
                        <div class="d-flex align-items-center mb-2">
                            <div class="bg-success bg-opacity-10 rounded p-2 me-2">
                                <i class="bi bi-spreadsheet text-success"></i>
                            </div>
                            <h5 class="mb-0">Manage in Google Sheets</h5>
                        </div>
                        <p class="text-muted mb-0 small">
                            Update content collaboratively; changes sync to your live site automatically.
                        </p>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="h-100 p-3 p-md-4 border rounded bg-light">
                        <div class="d-flex align-items-center mb-2">
                            <div class="bg-success bg-opacity-10 rounded p-2 me-2">
                                <i class="bi bi-lightning-charge text-success"></i>
                            </div>
                            <h5 class="mb-0">Launch super fast</h5>
                        </div>
                        <p class="text-muted mb-0 small">
                            Skip design and dev. Start from templates and publish in minutes.
                        </p>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="h-100 p-3 p-md-4 border rounded bg-light">
                        <div class="d-flex align-items-center mb-2">
                            <div class="bg-success bg-opacity-10 rounded p-2 me-2">
                                <i class="bi bi-shield-check text-success"></i>
                            </div>
                            <h5 class="mb-0">Peace-of-mind hosting</h5>
                        </div>
                        <p class="text-muted mb-0 small">
                            Free SSL, CDN, SEO, analytics, and more—handled for you.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script setup>
// Why section cards
</script>


