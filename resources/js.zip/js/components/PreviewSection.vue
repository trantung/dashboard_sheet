<template>
    <section class="py-5 bg-white">
        <div class="container">
            <div class="ratio ratio-16x9 border rounded shadow-sm overflow-hidden">
                <div class="bg-dark bg-opacity-10 d-flex align-items-center justify-content-center">
                    <div class="text-center p-3">
                        <i class="bi bi-play-circle text-success" style="font-size: 3rem;"></i>
                        <p class="text-muted mt-2 mb-0">Product tour / preview placeholder</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script setup>
// Video/preview area
</script>


