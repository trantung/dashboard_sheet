<template>
    <GuestLayout>
        <section class="py-5">
            <div class="container py-4 text-center">
                <h1 class="fw-bold mb-3">Showcase</h1>
                <p class="text-muted">Coming soon…</p>
            </div>
        </section>
    </GuestLayout>
</template>

<script setup>
import GuestLayout from '../layouts/GuestLayout.vue'
</script>


