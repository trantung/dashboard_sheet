<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Navbar</h4>
                <p class="text-muted mb-0">Customize your website navigation</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="bi bi-menu-button-wide fs-1 text-muted mb-3"></i>
                <h5 class="mb-2">Navigation Bar</h5>
                <p class="text-muted">Configure your website navigation menu</p>
            </div>
        </div>
    </div>
</template>