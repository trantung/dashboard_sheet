<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Webhooks</h4>
                <p class="text-muted mb-0">Configure webhooks</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="bi bi-webhook fs-1 text-muted mb-3"></i>
                <h5 class="mb-2">Webhook Configuration</h5>
                <p class="text-muted">Set up webhooks for your website</p>
            </div>
        </div>
    </div>
</template>