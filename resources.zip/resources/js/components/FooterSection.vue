<template>
    <footer class="bg-white border-top">
        <!-- CTA Section -->
        <section class="bg-dark text-white py-5">
            <div class="container py-4 text-center">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <h2 class="display-5 fw-bold mb-4">
                            Ready to Kickstart Your Website?
                        </h2>
                        <p class="lead text-light mb-4">
                            Transform your Google Sheets into beautiful websites in minutes. Start building your online
                            presence today.
                        </p>
                        <button class="btn btn-success btn-lg px-4 py-3">
                            Try it free today
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer Links -->
        <div class="bg-white py-5">
            <div class="container">
                <div class="text-center">
                    <!-- Logo -->
                    <div class="d-flex align-items-center justify-content-center mb-4">
                        <div class="me-2 d-flex align-items-center justify-content-center bg-success rounded-circle"
                            style="width: 32px; height: 32px;">
                            <i class="bi bi-lightning text-white"></i>
                        </div>
                        <span class="fs-4 fw-bold text-dark">Sheetany</span>
                    </div>

                    <!-- Footer Links -->
                    <div class="d-flex flex-wrap justify-content-center gap-4 mb-4">
                        <a href="#" class="text-muted text-decoration-none">Features</a>
                        <a href="#" class="text-muted text-decoration-none">Templates</a>
                        <a href="#" class="text-muted text-decoration-none">Blog</a>
                        <a href="#" class="text-muted text-decoration-none">Twitter</a>
                        <a href="#" class="text-muted text-decoration-none">Pricing</a>
                        <a href="#" class="text-muted text-decoration-none">Showcase</a>
                        <a href="#" class="text-muted text-decoration-none">Roadmap</a>
                        <a href="#" class="text-muted text-decoration-none">Changelog</a>
                        <a href="#" class="text-muted text-decoration-none">Terms</a>
                        <a href="#" class="text-muted text-decoration-none">Privacy</a>
                        <a href="#" class="text-muted text-decoration-none">Contact</a>
                        <a href="#" class="text-muted text-decoration-none">Affiliate</a>
                    </div>

                    <!-- Copyright -->
                    <div class="text-center">
                        <p class="text-muted mb-0">© 2024 Sheetany. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</template>

<script setup>
// Footer component
</script>