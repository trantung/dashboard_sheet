<template>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="d-flex align-items-center gap-2">
                <h4 class="mb-0">My Files</h4>
                <span class="badge bg-primary">BETA</span>
            </div>
            <button class="btn btn-success">
                <i class="bi bi-upload me-1"></i>
                Upload Image
            </button>
        </div>

        <div class="bg-white rounded p-5 text-center">
            <i class="bi bi-images fs-1 text-muted mb-3"></i>
            <p class="text-muted">No images uploaded yet.</p>
        </div>
    </div>
</template>