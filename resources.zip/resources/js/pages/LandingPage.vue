<template>
    <GuestLayout>
        <HeroSection />
        <FeaturesSection />
        <FooterSection />
    </GuestLayout>
</template>

<script setup>
import GuestLayout from '../layouts/GuestLayout.vue'
import HeroSection from '../components/HeroSection.vue'
import FeaturesSection from '../components/FeaturesSection.vue'
import FooterSection from '../components/FooterSection.vue'
</script>